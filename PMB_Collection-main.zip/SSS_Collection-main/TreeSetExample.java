package Collection.ClassesEx;

import java.util.TreeSet;

public class TreeSetExample {
    public static void main(String[] args) {
        TreeSet<String> treeSet = new TreeSet<>();
        treeSet.add("Apple");
        treeSet.add("Banana");
        treeSet.add("Mango");

        System.out.println("TreeSet: " + treeSet);
    }
}

