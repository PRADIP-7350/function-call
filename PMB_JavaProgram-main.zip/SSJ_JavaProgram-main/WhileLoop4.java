public class WhileLoop4 {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 5) {
            System.out.println("Hello");
            i++;
        }
    }
}
