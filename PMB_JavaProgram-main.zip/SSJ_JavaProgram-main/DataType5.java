public class DataType5 {
    public static void main(String[] args) {
        char c='7';
        System.out.println(c);
}
