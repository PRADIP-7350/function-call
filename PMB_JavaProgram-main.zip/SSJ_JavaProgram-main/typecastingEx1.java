public class typecastingEx1 {
    public static void main(String[] args) {
        double d=12345.6789;
        float f=(float)d;
        System.out.println("float value"+f);
        System.out.println("double value"+d);
    
    }
    
}
