public class typecastingEx3 {
    public static void main(String[] args) {
       char c='z';
       int i=(int)c;
        System.out.println("char"+c);
        System.out.println("int"+i);
      
    
    }
    
    
}
