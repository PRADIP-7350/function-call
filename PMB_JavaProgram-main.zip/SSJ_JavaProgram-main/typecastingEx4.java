public class typecastingEx4 {
    public static void main(String[] args) {
        float f=120.56f;
        byte b=(byte)f;
        System.out.println("float value"+f);
        System.out.println("byte value"+b);
      
    
    }
    
    
}
