public class DataType4 {
    public static void main(String[] args) {
        char x='7';//ASCII -55
        int r=x+3;
        System.out.println(r);
    
}
