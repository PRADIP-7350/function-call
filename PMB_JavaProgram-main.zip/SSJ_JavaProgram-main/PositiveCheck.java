public class PositiveCheck {
    public static void main(String[] args) {
        int number = 5;
        if (number > 0) {
            System.out.println(number + " is positive.");
        }
    }
    
}
