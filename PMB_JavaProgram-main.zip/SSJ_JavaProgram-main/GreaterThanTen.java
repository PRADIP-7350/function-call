public class GreaterThanTen {
    public static void main(String[] args) {
        int number = 15;
        if (number > 10) {
            System.out.println(number + " is greater than 10.");
        }
    }
    
}
