public class DataType10 {
    public static void main(String[] args) {
        long b=4287888l;
        System.out.println("value of float is"+b);
       }
    
}
