public class DefaultConstructor {
    public DefaultConstructor() {
        System.out.println("Default constructor called");
    }

    public static void main(String[] args) {
        DefaultConstructor obj = new DefaultConstructor();
    }
}
