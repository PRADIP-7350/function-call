public class typecasting7 {
    public static void main(String[] args) {
        byte b=10;
        int i=b;
        System.out.println("int value"+i);
      
    
    }
    
}
