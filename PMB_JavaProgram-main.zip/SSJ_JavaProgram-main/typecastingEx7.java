public class typecastingEx7 {
    public static void main(String[] args) {
       float f=123.45f;
       int i=(int)f;
        System.out.println("int"+i);
        System.out.println("float"+f);
    }
}
