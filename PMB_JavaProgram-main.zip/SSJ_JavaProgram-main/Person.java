public class Person {
    String name;
    int age;
    public static void main(String[] args) {
        Person person=new Person();
        person.name="om";
        person.age=21;
        System.out.println("name"+person.name);
        System.out.println("age"+person.age);

        
    }
    
}
