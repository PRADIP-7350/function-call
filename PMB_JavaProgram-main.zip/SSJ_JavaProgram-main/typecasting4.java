public class typecasting4 {
    public static void main(String[] args) {
        char ch='c';
        int num=88;
        ch=num;
    }
    
}
