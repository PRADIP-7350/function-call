public class PositiveNegativeCheck {
    public static void main(String[] args) {
        int number = -2;
        if (number >= 0) {
            System.out.println(number + " is positive.");
        } else {
            System.out.println(number + " is negative.");
        }
    }
}
