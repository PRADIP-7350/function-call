public class Book {
    String title;
    int pages;
    public static void main(String[] args) {
        Book book=new Book();
        book.title="chava";
        book.pages=999;
        System.out.println("name of book "+book.title);
        System.out.println("pages is"+book.pages);
    }
    
}
