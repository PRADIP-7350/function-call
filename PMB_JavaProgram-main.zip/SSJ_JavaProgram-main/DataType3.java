public class DataType3 {
    public static void main(String[] args) {
        int i=7;
        int r=i+3;
        System.out.println(r);
    
}
