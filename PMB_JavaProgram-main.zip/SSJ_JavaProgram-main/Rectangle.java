public class Rectangle {
    double length;
    double width;
    public static void main(String[] args) {
        Rectangle r=new Rectangle();
        r.length=52;
        r.width=20;
        System.out.println(r.length);
        System.out.println(r.width);
    }
    
}
