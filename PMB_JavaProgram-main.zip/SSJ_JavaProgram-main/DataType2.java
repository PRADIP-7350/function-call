public class DataType2 {
    public static void main(String[] args) {
        boolean=TRUE;
        System.out.println(boolean);
    
}
