public class DataType9 {
    public static void main(String[] args) {
        float x=3.14f;
        System.out.println("value of float is"+x);
    
}
