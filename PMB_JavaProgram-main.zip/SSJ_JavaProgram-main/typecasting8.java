public class typecasting8 {
    public static void main(String[] args) {
        short s=12345;
        long l=s;
        System.out.println("int value"+l);
    
    }
    
}
