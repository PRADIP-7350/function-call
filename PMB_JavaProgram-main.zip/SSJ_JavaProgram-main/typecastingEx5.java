public class typecastingEx5 {
    public static void main(String[] args) {
        int i=65;
        char c=(char)i;
        System.out.println("int"+i);
        System.out.println("char"+c);
    }
    
}
