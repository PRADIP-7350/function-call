public class typecastingEx2 {
    public static void main(String[] args) {
        double d=9.99;
        int i=(int)d;
        System.out.println("byte value"+d);
        System.out.println("int value"+i);
      
    
    }
    
}
