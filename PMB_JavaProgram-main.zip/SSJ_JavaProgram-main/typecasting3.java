public class typecasting3 {
         public static void main(String[] args) {
        char c=32;
        System.out.println("value"+c+"hi");
    } 
    
}
