public class typecastingEx6 {
    public static void main(String[] args) {
       long l=12345678910l;
       int i=(int)l;
        System.out.println("double"+i);
        System.out.println("long"+l);
    }
}
