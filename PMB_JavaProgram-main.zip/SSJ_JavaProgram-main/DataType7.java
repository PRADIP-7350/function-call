public class DataType7 {
    public static void main(String[] args) {
        double x=3.14f;
        System.out.println("value of double is"+x);
}
