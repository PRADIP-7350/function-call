public class DataTypes {

   /* 1>integer=
   public static void main(String[] args){
        int x=10;
        int y=x+3;
        System.out.println(y);
    } */

     /* int
   public static void main(String[] args) {
    int b=45;
    System.out.println("value of int is"+b);
   }*/


   /* 2>byte= 
   public static void main(String[] args ) {
    byte b=20;
    System.out.println("value of int is"+b);


   }*/

   /*2>byte= error
   public static void main(String[] args) {
    byte b=129;
    System.out.println("value of byte is"+b);
   }*/

   /*short=
   public static void main(String[] args) {
    short b=32767;
    System.out.println("value of short is"+b);
   }*/


   /*long=
   public static void main(String[] args) {
    long b=4287888;
    System.out.println("value of long is"+b);
   } */
   
  

  public static void main(String[] args) {
    System.out.println(5+3);
  }
}