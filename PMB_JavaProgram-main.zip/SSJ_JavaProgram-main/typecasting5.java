public class typecasting5 {
    public static void main(String[] args) {
        int i=100;
        double d=i;
        System.out.println("int value"+i);
        System.out.println("int value"+d);
    
    }
   

    
}
