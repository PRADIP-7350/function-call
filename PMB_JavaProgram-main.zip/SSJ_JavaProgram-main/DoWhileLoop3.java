public class DoWhileLoop3 {
    public static void main(String[] args) {
        int i = 1;
        do {
            System.out.println("Hello");
            i++;
        } while (i <= 3);
    }
}
