public class ForLoop3 {
    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            System.out.println("Hello");
        }
    } 
}
