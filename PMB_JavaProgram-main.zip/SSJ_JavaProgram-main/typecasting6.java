public class typecasting6 {
    public static void main(String[] args) {
        float f=3.14f;
        double d=f;
        System.out.println("double value"+d);
    
    }
    
}
