public class NegativeCheck {
    public static void main(String[] args) {
        int number = -3;
        if (number < 0) {
            System.out.println(number + " is negative.");
        }
    }
}
