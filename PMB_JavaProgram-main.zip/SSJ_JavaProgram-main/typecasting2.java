public class typecasting2 {
  
   public static void main(String[] args) {
    char c=97;
    System.out.println("value"+c+"hi");
   }
    
}
