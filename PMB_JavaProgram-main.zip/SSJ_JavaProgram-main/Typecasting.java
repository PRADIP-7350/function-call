public class Typecasting {

  public static void main(String[] args) {
    char c=2309;
    System.out.println("value"+c+"hi");
  }
}
